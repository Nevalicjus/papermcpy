# papermcpy

Simple Python API Wrapper for [PaperMC's Downloads API](https://papermc.io/api/docs/swagger-ui/index.html?configUrl=/api/openapi/swagger-config)
